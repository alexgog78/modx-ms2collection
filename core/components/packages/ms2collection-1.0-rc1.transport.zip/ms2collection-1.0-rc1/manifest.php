<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Collection.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Collection
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Collection
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '700dfb06b0255ce64a20f4e9cbde080a',
      'native_key' => 'ms2collection',
      'filename' => 'modNamespace/cc1e9252133f62b831a9ce2dc90152ae.vehicle',
      'namespace' => 'ms2collection',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'cad6bdc8f7bf80e7c3c505297480fb3b',
      'native_key' => 'cad6bdc8f7bf80e7c3c505297480fb3b',
      'filename' => 'xPDOFileVehicle/66fdf3ac49def9c2531845fb4989595a.vehicle',
      'namespace' => 'ms2collection',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0b60e0a7d6a13e4d19fa99b93978528f',
      'native_key' => '0b60e0a7d6a13e4d19fa99b93978528f',
      'filename' => 'xPDOFileVehicle/6f152c5c77eb3f5a697d99c39dce5db6.vehicle',
      'namespace' => 'ms2collection',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2156f771c7f11a4d5cf63d39860c62e9',
      'native_key' => 1,
      'filename' => 'modCategory/7e455ed1b3cea0750bdc850c2dbbd9ca.vehicle',
      'namespace' => 'ms2collection',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'eba9862278b78cd91afbfe89973c5fd5',
      'native_key' => 'eba9862278b78cd91afbfe89973c5fd5',
      'filename' => 'xPDOScriptVehicle/626ac57b668c3645c81fed631d2b68d3.vehicle',
      'namespace' => 'ms2collection',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '61516fb066042634e944f28a10d686fc',
      'native_key' => '61516fb066042634e944f28a10d686fc',
      'filename' => 'xPDOScriptVehicle/c1ff13b9c981c56e06fbe173a57809e2.vehicle',
      'namespace' => 'ms2collection',
    ),
  ),
);