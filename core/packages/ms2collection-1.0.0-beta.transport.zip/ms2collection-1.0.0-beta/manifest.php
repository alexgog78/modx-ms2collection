<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Collection.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Collection
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Collection
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3db892f3800d42279056d455978cac0b',
      'native_key' => 'ms2collection',
      'filename' => 'modNamespace/847f6e7afe800d0bdf5ad67ae5029b38.vehicle',
      'namespace' => 'ms2collection',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6e07bc006eed2ad1d35d6b9a146a6eea',
      'native_key' => '6e07bc006eed2ad1d35d6b9a146a6eea',
      'filename' => 'xPDOFileVehicle/9b998f11a9dfe4e0b01475e5a1d95c71.vehicle',
      'namespace' => 'ms2collection',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '60af53fa102b3e73a5936a67d65c1482',
      'native_key' => '60af53fa102b3e73a5936a67d65c1482',
      'filename' => 'xPDOFileVehicle/d59de51fc0da197f2521f9d3610f3e19.vehicle',
      'namespace' => 'ms2collection',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'cc7a01e65cf903c65135a2d537ad398a',
      'native_key' => 1,
      'filename' => 'modCategory/2b7ad6640a5001f87a8a35dc23c1db9d.vehicle',
      'namespace' => 'ms2collection',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'ddf069a656188520bf154868f501e4e4',
      'native_key' => 'ddf069a656188520bf154868f501e4e4',
      'filename' => 'xPDOScriptVehicle/4b4a4bdc62b7cc70cdae78f8a7d59c30.vehicle',
      'namespace' => 'ms2collection',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '9401a1d362dad7859ea82f426591aca0',
      'native_key' => '9401a1d362dad7859ea82f426591aca0',
      'filename' => 'xPDOScriptVehicle/0a8ce56fc0c4a9a67e18e61a934e84a7.vehicle',
      'namespace' => 'ms2collection',
    ),
  ),
);