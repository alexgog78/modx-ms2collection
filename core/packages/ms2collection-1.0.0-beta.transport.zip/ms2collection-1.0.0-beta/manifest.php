<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for ms2Collection.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
ms2Collection
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'ms2Collection
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b208a3e843f67c0506de2c022d8f0726',
      'native_key' => 'ms2collection',
      'filename' => 'modNamespace/5bb1b62d5274e22a3ff22848c8b65496.vehicle',
      'namespace' => 'ms2collection',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4f0fe61c2bb7f8687558ec121f37057f',
      'native_key' => '4f0fe61c2bb7f8687558ec121f37057f',
      'filename' => 'xPDOFileVehicle/474e72e2b763077f4c8eb1dd83651149.vehicle',
      'namespace' => 'ms2collection',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '369a709ff5610461d67f80b4e39f6182',
      'native_key' => '369a709ff5610461d67f80b4e39f6182',
      'filename' => 'xPDOFileVehicle/ec52cb4f57ffb98447be60d5c8a66684.vehicle',
      'namespace' => 'ms2collection',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '73d709dbd656ffd1742100ddfa1dd1df',
      'native_key' => 1,
      'filename' => 'modCategory/5aeaec9e29ab2b6c28cb95d38e52a88b.vehicle',
      'namespace' => 'ms2collection',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'f99f035593f54ea5cc103599518d3a8f',
      'native_key' => 'f99f035593f54ea5cc103599518d3a8f',
      'filename' => 'xPDOScriptVehicle/41df934181659396ee9de3f2673935ab.vehicle',
      'namespace' => 'ms2collection',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '2e1c1970a3706c02f49b2ec16ef7f353',
      'native_key' => '2e1c1970a3706c02f49b2ec16ef7f353',
      'filename' => 'xPDOScriptVehicle/4fbf3173bc09834525ba075fb572540c.vehicle',
      'namespace' => 'ms2collection',
    ),
  ),
);