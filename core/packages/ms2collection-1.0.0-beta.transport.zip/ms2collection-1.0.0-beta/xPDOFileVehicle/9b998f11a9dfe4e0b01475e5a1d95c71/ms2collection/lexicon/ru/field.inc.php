<?php

$prefix = 'ms2collection.';

$_lang[$prefix . 'field.undefined'] = '<span class="icon icon-lock" style="font-size: 200%;"></span><br />Для начала сохраните объект';
$_lang[$prefix . 'field.indevelopment'] = '<span class="icon icon-cog" style="font-size: 200%;"></span><br />Раздел находится в разработке';
