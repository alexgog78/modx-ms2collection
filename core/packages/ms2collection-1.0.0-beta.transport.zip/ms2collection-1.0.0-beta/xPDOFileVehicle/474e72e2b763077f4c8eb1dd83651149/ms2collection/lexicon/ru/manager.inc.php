<?php

$prefix = 'ms2collection.';

$_lang[$prefix . 'tab.collection'] = 'Коллекция товаров';
$_lang[$prefix . 'tab.collection.management'] = 'Товары состоящие в одной коллекции с данным. Эти товары по умолчанию будут сохранены в той-же категории что и родительский.';
