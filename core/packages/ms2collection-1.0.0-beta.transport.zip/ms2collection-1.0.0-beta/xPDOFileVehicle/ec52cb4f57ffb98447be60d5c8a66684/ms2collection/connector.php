<?php

define('PKG_NAME', 'ms2Collection');
define('PKG_NAME_LOWER', 'ms2collection');

require_once dirname(dirname(__FILE__)) . '/abstractmodule/connector.php';
